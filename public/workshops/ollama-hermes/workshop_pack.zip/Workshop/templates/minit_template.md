# MINIT MESYUARAT [NAMA JAWATANKUASA] BIL. [X]/[TAHUN]

**Tarikh:** [hari, tarikh]
**Masa:** [mula] – [tamat]
**Tempat:** [lokasi / dalam talian]

## KEHADIRAN
1. [Nama] – Pengerusi
2. [Nama] – Setiausaha
3. [Nama]

**Turut hadir (dalam talian):** [Nama]
**Memohon maaf:** [Nama]

## 1.0 PERUTUSAN PENGERUSI
1.1 [Ringkasan]

## 2.0 PENGESAHAN MINIT MESYUARAT BIL. [X-1]/[TAHUN]
2.1 [Pindaan, jika ada]
2.2 Minit disahkan dengan/tanpa pindaan. Dicadangkan oleh [Nama] dan disokong oleh [Nama].

## 3.0 PERKARA BERBANGKIT
3.1 [Perkara]
 **Keputusan:** [...]
 **Tindakan:** [Nama] – [tarikh akhir]

## 4.0 [PERKARA BAHARU]
4.1 [...]

## 5.0 HAL-HAL LAIN
5.1 [...]

## 6.0 PENANGGUHAN
Mesyuarat ditangguhkan pada jam [masa]. Mesyuarat seterusnya dijadualkan pada [tarikh, masa].

---

### RINGKASAN TINDAKAN

| Bil. | Perkara | Tindakan oleh | Tarikh akhir |
|---|---|---|---|
| 1 | [...] | [...] | [...] |

### PERKARA UNTUK DISAHKAN [SAHKAN]
- [Perkara yang tidak jelas dalam catatan asal]

Disediakan oleh: [Nama Setiausaha]
Disemak oleh: [Nama Pengerusi]
