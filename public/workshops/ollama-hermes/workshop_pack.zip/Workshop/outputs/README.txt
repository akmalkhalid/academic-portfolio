This folder is empty on purpose. Ask the agent to save its results here, so your original files stay untouched.
