# Bengkel AI Tempatan: Ollama + Hermes Agent — Soalan Lazim (FAQ)

**Practice file for the workshop.** The agent should answer event enquiries **only** from this file. If a question is not covered here, it should reply that the secretariat will follow up, and it should not guess.

> Event details below are fictional placeholders for training. Replace them with your real event before using this file for real enquiries.

---

## 1. Maklumat asas / Basic details

| | |
|---|---|
| **Tarikh / Date** | Rabu, 12 November 2026 / Wednesday, 12 November 2026 |
| **Masa / Time** | 8.30 pagi – 1.00 petang (pendaftaran 8.00 pagi) / 8:30 am – 1:00 pm (registration from 8:00 am) |
| **Tempat / Venue** | Makmal 1 dan 2, Aras 1, Fakulti Teknologi dan Sains Maklumat (FTSM) |
| **Penganjur / Organiser** | Jawatankuasa Bengkel AI, FTSM |
| **Yuran / Fee** | Percuma untuk staf universiti / Free for university staff |
| **Bahasa / Language** | Bahasa Melayu dan Bahasa Inggeris / Malay and English |

## 2. Pendaftaran / Registration

**Bagaimana mendaftar? / How do I register?**
Melalui borang dalam talian yang diedarkan dalam emel jemputan. Pendaftaran ditutup pada **31 Oktober 2026, jam 5.00 petang**. Selepas itu, nama akan dimasukkan ke senarai menunggu.
Use the online form in the invitation email. Registration closes on **31 October 2026 at 5:00 pm**; after that you will be placed on a waiting list.

**Saya sudah mendaftar dua kali. Perlu batal satu? / I registered twice. Should I cancel one?**
Tidak perlu. Urusetia akan menggabungkan rekod. Maklumkan sahaja maklumat yang betul jika ada perubahan.
No need. The secretariat will merge duplicate records. Just tell us which details are correct if anything changed.

**Bolehkah saya datang tanpa mendaftar? / Can I walk in?**
Tidak. Kapasiti makmal terhad. Sila daftar atau masuk senarai menunggu.
No. Lab capacity is limited, so please register or join the waiting list.

**Bolehkah saya hadir separuh masa sahaja? / Can I attend only part of the day?**
Boleh, tetapi Modul 2 dan 3 bergantung pada persediaan dalam Modul 1. Sila nyatakan sesi pilihan semasa mendaftar.
Yes, but Modules 2 and 3 build on Module 1. Please state your preferred session when registering.

## 3. Komputer riba / Laptop

**Adakah saya perlu membawa komputer riba? / Do I need to bring a laptop?**
Ya, digalakkan. Spesifikasi minimum: Windows 10/11 (64-bit) atau Mac Apple silicon (M1 ke atas), RAM 8 GB (16 GB disyorkan), ruang cakera 15 GB kosong.
Yes, please. Minimum: Windows 10/11 (64-bit) or an Apple silicon Mac (M1 or newer), 8 GB RAM (16 GB recommended) and 15 GB free disk space.

**Saya menggunakan Mac Intel. / I have an Intel Mac.**
Hermes Agent tidak menyokong Mac Intel. Komputer makmal yang telah dipasang siap disediakan untuk anda.
Hermes Agent does not support Intel Macs. A pre-installed lab PC will be reserved for you.

**Komputer riba universiti saya tidak membenarkan pemasangan perisian. / My university laptop blocks software installs.**
Urusetia sedang memohon kebenaran sementara daripada pejabat IT. Jika tidak diluluskan, anda akan menggunakan komputer makmal.
The secretariat is requesting temporary permission from the IT office. If it is not granted, you will use a lab PC.

**Apa yang perlu dipasang sebelum hari bengkel? / What should I install beforehand?**
1. Ollama dari **ollama.com/download**
2. Model: buka terminal dan taip `ollama pull qwen3:8b` (atau `ollama pull qwen3:4b` jika RAM 8 GB)
3. Semak: `ollama --version`

Muat turun model di rumah atau pejabat. Saiznya beberapa GB dan rangkaian Wi-Fi makmal tidak mampu menampung muat turun serentak.
Download the model at home or in your office. It is several GB, and the lab Wi-Fi cannot handle everyone downloading at once.

## 4. Kemudahan / Facilities

**Tempat letak kereta / Parking**
Tempat letak kereta staf di hadapan bangunan fakulti boleh digunakan. Sila paparkan pas staf. Tempat letak kereta pelawat terhad.
Staff parking in front of the faculty building is available. Please display your staff pass. Visitor parking is limited.

**Makanan / Food**
Minum pagi dan makan tengah hari disediakan. Semua hidangan halal. Pilihan vegetarian dan keperluan alahan disediakan jika dinyatakan semasa pendaftaran sebelum **5 November 2026**.
Morning tea and lunch are provided. All food is halal. Vegetarian and allergy options are available if stated in your registration before **5 November 2026**.

**Surau / Prayer room**
Surau terletak di Aras 1, bersebelahan Makmal 2.
The prayer room is on Level 1, next to Lab 2.

**Akses OKU / Accessibility**
Bangunan mempunyai lif dan laluan kerusi roda. Maklumkan urusetia jika memerlukan bantuan khas.
The building has a lift and wheelchair access. Tell the secretariat if you need any special assistance.

## 5. Sijil dan rakaman / Certificates and recording

**Sijil / Certificate**
E-sijil dihantar melalui emel selepas anda mengisi borang maklum balas (kod QR pada slaid terakhir).
An e-certificate is emailed after you complete the feedback form (QR code on the last slide).

**Adakah sesi dirakam? / Is the session recorded?**
Mungkin. Jika dirakam, notis persetujuan akan dihantar melalui emel terlebih dahulu.
Possibly. If it is recorded, a consent notice will be emailed in advance.

## 6. Data dan privasi / Data and privacy

**Adakah data saya dihantar ke luar? / Does my data leave my laptop?**
Model tempatan (contohnya `qwen3:8b`) berjalan sepenuhnya pada komputer anda. Model berakhiran `:cloud` dijalankan pada pelayan Ollama, jadi data anda dihantar ke luar. Semua latihan menggunakan data rekaan sahaja.
Local models (such as `qwen3:8b`) run entirely on your computer. Models ending in `:cloud` run on Ollama's servers, so your data leaves the laptop. All exercises use invented data only.

## 7. Hubungi urusetia / Contact

- Emel / Email: bengkel.ai@staf.example.edu.my
- Waktu pejabat / Office hours: Isnin–Jumaat, 8.30 pagi – 4.30 petang / Monday–Friday, 8:30 am – 4:30 pm

---

*Kemas kini terakhir / Last updated: 20 Oktober 2026*
