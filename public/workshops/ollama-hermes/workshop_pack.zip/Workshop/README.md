# Workshop practice pack: Ollama + Hermes Agent

Unzip this folder into **Documents** so that you have `Documents/Workshop/`.

Everything in this pack is **invented**: names, matric numbers, emails, phone numbers, the manuscript and its results. Practise freely. Never practise on real student or staff data.

## What is inside

| Folder | File | Used in |
|---|---|---|
| `students/` | `students.csv`: 526 rows of a messy student register (missing, inconsistent, duplicated and out-of-range values) | Case 1 · CRUD |
| `reviews/` | `manuscript_042.pdf`: a 29-page fictional journal manuscript (`.txt` copy included) | Case 2 · reviewer |
| `reviews/` | `my_notes.txt`: a reviewer's rough notes | Case 2 · Lane B |
| `reviews/` | `reviewer_comments.txt`: a fictional "major revision" decision letter | Case 2 · author |
| `events/` | `rsvp_week1.csv`, `rsvp_week2.csv`, `rsvp_late.csv`: RSVPs from three different sources | Case 3 · data collection |
| `events/` | `meeting_notes.txt`: rough notes from a two-hour committee meeting | Case 3 · minutes |
| `events/` | `FAQ.md`: bilingual event FAQ for the email agent | Case 3 · auto-reply |
| `templates/` | `minit_template.md`: formal meeting-minutes template (BM) | Case 3 · minutes |
| `outputs/` | (empty) | Ask the agent to save results here |

## Starter prompts

**Case 1: student records**
1. "First, copy students/students.csv to students/students_backup.csv."
2. "Profile students.csv: how many rows, duplicates, blank cells and inconsistent values per column? Don't change anything yet."
3. "Create outputs/students_clean.csv with standardised programme names, phone numbers (01X-XXXXXXX), dates (YYYY-MM-DD) and gender (M/F). List every row you could not fix in outputs/needs_review.csv."
4. "Which Year 1 students have attendance below 80%? Show a table."
5. "Add a new student: A219999, Nur Iman binti Hassan, BSc Data Science, Year 1."
6. "Move withdrawn students to outputs/withdrawn.csv instead of deleting them."

**Case 2: article review and revision**
- Lane A: "Read reviews/manuscript_042.pdf. Draft a reviewer report: 3-sentence summary, strengths, major concerns, minor issues, questions for the authors. Cite page or line numbers. No accept/reject verdict. Save to outputs/review_042.md."
- Lane B: "Turn reviews/my_notes.txt into a structured reviewer report. Fix grammar only. Do not add new points."
- Author: "Read reviews/reviewer_comments.txt. Build a response table: comment number, comment, polite draft reply, where to change. Mark anything needing new experiments as [AUTHOR TO DECIDE]. Save to outputs/response_table.md."

**Case 3: automation**
- "Merge events/rsvp_*.csv into outputs/attendees.csv. Note that rsvp_late.csv uses semicolons. Remove duplicates, then count attendees by faculty, diet and session."
- "Turn events/meeting_notes.txt into formal minutes in Bahasa Malaysia using templates/minit_template.md. Mark anything unclear as [SAHKAN]. Save to outputs/minit_bil3_2026.md."
- "Every weekday at 8 am, re-run the RSVP merge and save a 5-line summary to outputs/rsvp_summary.md."
- Email agent: "Answer event enquiries only from events/FAQ.md. If the answer is not there, say the secretariat will reply."

**Tip:** if the agent struggles with the PDF, point it to `reviews/manuscript_042.txt` instead.
